<header class="container-fluid head">
    <div class="row">
        <div class="col-sm-4">
        </div>
        <div class="col-sm-4">
            <img src="http://localhost/Projekt/images/logo.png" alt="headerLogo" id="headerImage" >
        </div>
        <div class="col-sm-4">
        </div>
    </div>
    <div class="row">
            <ul class="nav">
                <li class="col-md-1 col-sm-12"></li>
                <a href="http://localhost/Projekt/index.php" class="navListItem col-md-2 col-sm-12 aClass">
                    <li>Home</li>
                </a>
                <a href="http://localhost/Projekt/insert.html" class="navListItem col-md-2 col-sm-12">
                <li>Insert</li>
                </a>
                <li class="navListItem col-md-2 col-sm-12">Economie</li>
                <li class="navListItem col-md-2 col-sm-12">Administracija</li>
                <li class="navListItem col-md-2 col-sm-12">Offers locales</li>
                <li class="col-md-1 col-sm-12"></li>
            </ul>
    </div>      
</header>