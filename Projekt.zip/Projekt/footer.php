<footer>
        <div class="container-fluid">
            <div class="row">
                <p class="col-md-2"></p>
                <p class="col-md-3">Tome Veršić</p>
                <p class="col-md-3">tversic@tvz.hr</p>
                <p class="col-md-3">2021</p>
            </div>
        </div>
</footer>